# -*- coding: utf-8 -*-

# Entrada de dados. A, B são números inteiros.
A = int(input())
B = int(input())

# O operador % calcula o resto da divisão de dois números.
resto = A % B
print(resto)  # Imprime a resposta na tela.
