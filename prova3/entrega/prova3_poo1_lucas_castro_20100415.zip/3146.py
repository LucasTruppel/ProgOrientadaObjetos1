# -*- coding: utf-8 -*-

raio = float(input())  # Entrada do valor do raio da circunferência.
circunferencia = 2 * 3.14 * raio  # Calculo da medida da circunferência.
print(f'{circunferencia:.2f}')  # Impressão na tela do resultado com 2 casa decimais.
